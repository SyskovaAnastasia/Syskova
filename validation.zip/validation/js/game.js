function randomInteger(min, max) {
    let rand = min + Math.random() * (max + 1 - min);
    return Math.floor(rand); 
  };
let number = randomInteger(1, 10)


function f1(){
let i = 1;
let d = [];
while(true){
   
   let con = +prompt('Угадайте число от 1 до 10, у вас есть 5 попыток', '');
   if (con == number) {
    alert ('Вы угадали!')
    break
   }
   else if (con > number) {
    alert ('Вы ввели число больше, чем нужно')
   }
   else {
    alert ('Вы ввели число меньше, чем нужно')
   }

  if( i >= 5 ){
  console.log( `${con} и ${number}` )
  d.push(con);
  alert(' Ваши попытки закончились, сыграйте ещё раз!');
  f1 ()
  console.log( `Вы ввели числа ${ d } правильное число ${number}` );
  break
  };
 
if( con == null || con == ''){
    break 
  } else if( number == con ){
    alert( `Вы угадали правильное число! ${number}` )
    break
  } else if( con == new Number(con) && con <= 10){
      d.push(con);
     ++i
    console.log( `${con} и ${number}` )
  } 
} 

};

f1();
